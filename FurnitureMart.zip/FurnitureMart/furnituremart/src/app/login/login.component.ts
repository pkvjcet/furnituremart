import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username="";
  pwd="";
  usertype="";

  constructor(private api:ApiService,private router:Router) { }

  ngOnInit() {
  }
  LoginCheck(){
    window.alert(this.username);
    this.api.authenticateUser(this.username,this.pwd).subscribe((data)=>{
      if(JSON.parse(JSON.stringify(data)).length>0){
        window.alert("Login Success....");
        console.log(data[0].userFullName);
       
        if(data[0].userType=='owner'){
          this.router.navigate(['/owner']);
        }
        else if(data[0].userType=='customer'){
          this.router.navigate(['/customer']);
        }

       
      }
      else{
        window.alert("Invalid Credentials");
      }
     
    });
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IUser } from './home/user.model';


@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) { }
  addNewUser(user:IUser){
    return this.http.post("http://localhost:3000/insert",{"user":user})
  }
  authenticateUser(username:string,password:string){
    return this.http.post("http://localhost:3000/verify",{"userName":username,"userPassword":password})
  }
  
}


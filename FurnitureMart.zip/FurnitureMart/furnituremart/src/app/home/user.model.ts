export class IUser{
    constructor(
        public userFullName: string,
        public userName:string,
        public userPassword: string,
        public userType:string       
    ){}
}
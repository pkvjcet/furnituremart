const express=require('express');
const UserData = require('./src/model/Userdata');

var app=new express();

var bodyParser=require('body-parser');
const cors=require('cors');




app.use(cors());
app.use(bodyParser.json());

app.post('/insert',function(req,res){
    res.header("Access-Control-Allow-Origin", "*")
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    console.log(req.body);
    var user = {       
        userFullName : req.body.user.userFullName,
        userName : req.body.user.userName,
        userPassword : req.body.user.userPassword,
        userType : req.body.user.userType       
   }       
   var user = new UserData(user);
   user.save();
   res.send("Successfully Inserted");
});
app.post('/verify',function(req,res){
    res.header("Access-Control-Allow-Origin", "*")
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    var userName=req.body.userName;
    var userPassword=req.body.userPassword;
    console.log(userName+userPassword)
    UserData.find({userName:userName,userPassword:userPassword}).then((user)=>{
        console.log(user);
        res.send(user);
    });
    

   //res.send("Successfully Inserted");
});



app.post('/testing',function(req,res){
    res.header("Access-Control-Allow-Origin", "*")
    res.header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    console.log('testing call');
    
});

app.listen(process.env.PORT ||3000, function(){
    console.log('listening to port 3000');
});

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/productsdb', { useNewUrlParser: true ,useUnifiedTopology: true });

const Schema = mongoose.Schema;

var NewUserSchema = new Schema({
    userFullName : String,
    userName : String,
    userPassword : String,
    userType : String    
});

var Userdata = mongoose.model('user', NewUserSchema);                        //UserData is the model and NewBookData is the schema

module.exports = Userdata;